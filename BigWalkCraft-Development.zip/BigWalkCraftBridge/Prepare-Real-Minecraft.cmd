@echo off
setlocal
set "craftRoot=%~dp0..\.."
set "JAVA_HOME=%craftRoot%\work\tools\jdk25\jdk-25.0.4.1+1"
set "GRADLE_USER_HOME=%craftRoot%\work\tools\gradle-cache"
set "BWMC_DIR=%craftRoot%\work\bridge\runtime"
set "ERMC_DIR=%BWMC_DIR%"
set "BWMC_GAME_DIR=%craftRoot%\work\bridge\minecraft-run"
set "BWMC_BUILD_DIR=%craftRoot%\work\bridge\guest-build"
if not exist "%JAVA_HOME%\bin\java.exe" (
 echo The prepared Java tools are missing. Use this file in its original folder.
 goto end
)
echo Preparing real Minecraft for Big Walk. This may take several minutes the first time.
echo Game files and saves stay in the private test folder.
echo Keep this window open until preparation finishes.
call "%~dp0guest\gradlew.bat" -p "%~dp0guest" build --no-daemon --no-configuration-cache > "%craftRoot%\work\bridge\guest-build-normal.log" 2>&1
if errorlevel 1 (
 echo Preparation stopped. The build log has been saved for diagnosis.
 type "%craftRoot%\work\bridge\guest-build-normal.log"
 goto end
)
> "%BWMC_BUILD_DIR%\guest-ready.txt" echo Minecraft guest build completed.
echo PREPARATION COMPLETE. You can close this window.
:end
pause
