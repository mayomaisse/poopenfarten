@echo off
setlocal
set "craftRoot=%~dp0..\.."
set "craftLab=%craftRoot%\work\lab\Big Walk"
set "JAVA_HOME=%craftRoot%\work\tools\jdk25\jdk-25.0.4.1+1"
set "GRADLE_USER_HOME=%craftRoot%\work\tools\gradle-cache"
set "BWMC_DIR=%craftRoot%\work\bridge\runtime"
set "ERMC_DIR=%BWMC_DIR%"
set "BWMC_GAME_DIR=%craftRoot%\work\bridge\minecraft-run"
set "BWMC_BUILD_DIR=%craftRoot%\work\bridge\guest-build"
if not exist "%BWMC_BUILD_DIR%\guest-ready.txt" (
 echo Run Prepare-Real-Minecraft.cmd first and wait for PREPARATION COMPLETE.
 goto end
)
if not exist "%craftLab%\Big Walk.exe" (
 echo The private Big Walk test copy is missing. Use this launcher in its original folder.
 goto end
)
tasklist /FI "IMAGENAME eq steam.exe" /NH | find /I "steam.exe" >nul
if errorlevel 1 (
 echo Open Steam first.
 goto end
)
tasklist /FI "IMAGENAME eq Big Walk.exe" /NH | find /I "Big Walk.exe" >nul
if not errorlevel 1 (
 echo Close Big Walk before starting the real Minecraft bridge.
 goto end
)
if exist "%craftLab%\BepInEx\plugins\BigWalkCraft\BigWalkCraft.dll" move /Y "%craftLab%\BepInEx\plugins\BigWalkCraft\BigWalkCraft.dll" "%craftLab%\BepInEx\plugins\BigWalkCraft\BigWalkCraft.dll.disabled" >nul
if not exist "%craftLab%\BepInEx\plugins\BigWalkMinecraftBridge" mkdir "%craftLab%\BepInEx\plugins\BigWalkMinecraftBridge"
copy /Y "%~dp0BepInEx\plugins\BigWalkMinecraftBridge\BigWalkMinecraftBridge.dll" "%craftLab%\BepInEx\plugins\BigWalkMinecraftBridge\BigWalkMinecraftBridge.dll" >nul
if errorlevel 1 goto copyerror
copy /Y "%~dp0BepInEx\plugins\BigWalkMinecraftBridge\BigWalkMinecraftRenderer.dll" "%craftLab%\BepInEx\plugins\BigWalkMinecraftBridge\BigWalkMinecraftRenderer.dll" >nul
if errorlevel 1 goto copyerror
set "SteamAppId=1478500"
set "SteamGameId=1478500"
echo Starting Big Walk and real Minecraft. Keep this window open.
echo Enter a solo Big Walk save normally. Minecraft should join automatically when ready.
echo F8 switches between Minecraft and Big Walk controls.
start "" /D "%craftLab%" "%craftLab%\Big Walk.exe" -force-d3d11 -screen-fullscreen 0
call "%~dp0guest\gradlew.bat" -p "%~dp0guest" runClient --no-daemon --no-configuration-cache > "%craftRoot%\work\bridge\guest-runtime-normal.log" 2>&1
if errorlevel 1 echo Minecraft stopped with an error. Its log has been saved for diagnosis.
goto end
:copyerror
echo Could not install the bridge into the private copy. Make sure Big Walk is fully closed.
:end
pause
