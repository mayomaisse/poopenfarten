using System;
using System.IO.MemoryMappedFiles;
using System.Text;
using System.Threading;
using UnityEngine;

namespace BigWalkMinecraftBridge;
// Calls the game's own interaction actions; no puzzle state is set directly.
internal sealed class NativeInteractions
{
    private readonly BridgeController _owner;
    private readonly MemoryMappedViewAccessor _memory;
    private int _dropRequest,_useRequest,_promptSeq;
    private string _prompt="";
    private float _nextPrompt;
    private PlayerCharacter? _switchPlayer;
    private PeckSwitch? _worldSwitch;
    private PeckContext? _switchContext;
    private Prop? _usedProp;
    internal NativeInteractions(BridgeController owner,MemoryMappedViewAccessor memory)
    {
        _owner=owner;_memory=memory;
        _dropRequest=memory.ReadInt32(Protocol.H_MC_DROP_REQ);_useRequest=memory.ReadInt32(Protocol.H_MC_USE_REQ);
        memory.Write(Protocol.H_HOST_ACTION_ACK,memory.ReadInt32(Protocol.H_MC_ACTION_REQ));
        memory.Write(Protocol.H_MC_INTERACTION_BUTTONS,0);
        Prompt("");
    }
    internal void Tick(bool active)
    {
        int request=_memory.ReadInt32(Protocol.H_MC_ACTION_REQ),drop=_memory.ReadInt32(Protocol.H_MC_DROP_REQ),use=_memory.ReadInt32(Protocol.H_MC_USE_REQ);
        if(!active || _owner.Player==null)
        {
            Release();Prompt("");_dropRequest=drop;_useRequest=use;
            if(request!=_memory.ReadInt32(Protocol.H_HOST_ACTION_ACK))Acknowledge(request,-3);
            return;
        }
        var p=_owner.Player;
        try
        {
            _owner.ApplyPose();
            int buttons=_memory.ReadInt32(Protocol.H_MC_INTERACTION_BUTTONS);
            if(_worldSwitch!=null && ((buttons&1)==0 || !p.caster.CanStillReachSwitch(_worldSwitch)))ReleaseWorld();
            if(_usedProp!=null && ((buttons&2)==0 || p.hands.heldProp?.Pointer!=_usedProp.Pointer))ReleaseHeld();
            if(drop!=_dropRequest)
            {
                _dropRequest=drop;Release();
                if(p.hands.isHoldingSomething) { p.actions.ActionDropPropOrPlayer();Log("Dropped held object"); }
            }
            if(use!=_useRequest)
            {
                _useRequest=use;
                var prop=p.hands.heldProp;
                if(prop?.useHeldSwitch!=null && p.decisions.IsSafeToUseSwitch(prop.useHeldSwitch))
                {
                    ReleaseHeld();p.actions.ActionUseHeldSwitch();_usedProp=prop;Log("Used held object");
                    if((buttons&2)==0)ReleaseHeld();
                }
            }
            if(request!=_memory.ReadInt32(Protocol.H_HOST_ACTION_ACK))
            {
                p.caster.LocalUpdate();int result=Interact(p);
                Acknowledge(request,result);Log("Interaction result="+result);
                if((buttons&1)==0)ReleaseWorld();
            }
            if(Time.unscaledTime>=_nextPrompt)
            {
                _nextPrompt=Time.unscaledTime+.2f;p.caster.LocalUpdate();
                var target=p.caster.castableTarget;
                string prompt=target!=null && p.decisions.IsSafeToUseCastableTarget(target)?"Interact with object":
                    p.caster.castProp!=null && !p.hands.isHoldingSomething && p.hands.IsSafeToPickUp(p.caster.castProp)?"Pick up object":"";
                if(p.hands.heldProp!=null)prompt=(prompt.Length>0?prompt+" / ":"")+"[V] Use held / [G] Drop";
                Prompt(prompt);
            }
        }
        catch(Exception e) { Release();Acknowledge(request,-1);Prompt("");BridgePlugin.Instance.Log.LogError("Native interaction: "+e); }
    }
    private int Interact(PlayerCharacter p)
    {
        var target=p.caster.castableTarget;
        if(target!=null && p.decisions.IsSafeToUseCastableTarget(target))
        {
            if(!target.GetCastableOutcome(p,out var outcome) || !outcome.MatchesConditions(p))return 0;
            // Native pose movement needs its physics controller; F8 gives it control.
            if(outcome.playerPose!=null)return -2;
            ReleaseWorld();p.decisions.UseCastableTarget(target);
            RememberSwitch(p);return 1;
        }
        var prop=p.caster.castProp;
        if(prop!=null && !p.hands.isHoldingSomething && p.hands.IsSafeToPickUp(prop))
        { p.actions.ActionPickUpProp(prop,p.caster.hitPosition);return 2; }
        return 0;
    }
    private void RememberSwitch(PlayerCharacter p)
    {
        var value=p.decisions.heldDownSwitch;
        if(value==null)return;
        _switchPlayer=p;_worldSwitch=value;_switchContext=new PeckContext(p,p.hands.heldProp);
    }
    private void ReleaseWorld()
    {
        var p=_switchPlayer;var value=_worldSwitch;var context=_switchContext;
        _switchPlayer=null;_worldSwitch=null;_switchContext=null;
        if(p==null || value==null || context==null)return;
        try { p.actions.ActionReleaseWorldSwitch(value,context);if(p.decisions.heldDownSwitch?.Pointer==value.Pointer)p.decisions.heldDownSwitch=null; }
        catch(Exception e) { BridgePlugin.Instance.Log.LogWarning("World switch release: "+e.Message); }
    }
    private void ReleaseHeld()
    {
        var prop=_usedProp;_usedProp=null;var p=_owner.Player;
        if(prop==null || p?.hands.heldProp?.Pointer!=prop.Pointer || prop.useHeldUpSwitch==null)return;
        try { p.actions.ActionUseHeldUpSwitch(); }
        catch(Exception e) { BridgePlugin.Instance.Log.LogWarning("Held switch release: "+e.Message); }
    }
    internal void Release() { ReleaseWorld();ReleaseHeld(); }
    private void Acknowledge(int request,int result)
    { _memory.Write(Protocol.H_HOST_ACTION_RESULT,result);Thread.MemoryBarrier();_memory.Write(Protocol.H_HOST_ACTION_ACK,request); }
    private void Prompt(string value)
    {
        if(value==_prompt && _promptSeq!=0)return;_prompt=value;
        _memory.Write(Protocol.H_HOST_PROMPT_SEQ,++_promptSeq);Thread.MemoryBarrier();
        byte[] bytes=new byte[64];var text=Encoding.UTF8.GetBytes(value);Array.Copy(text,bytes,Math.Min(63,text.Length));
        _memory.WriteArray(Protocol.H_HOST_PROMPT,bytes,0,bytes.Length);Thread.MemoryBarrier();_memory.Write(Protocol.H_HOST_PROMPT_SEQ,++_promptSeq);
    }
    private static void Log(string value)=>BridgePlugin.Instance.Log.LogInfo("Big Walk object: "+value);
}
