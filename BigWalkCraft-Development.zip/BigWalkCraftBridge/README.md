# Real Minecraft inside Big Walk � development build 0.4.0

This replaces the custom imitation with an actual Minecraft Java process. Native Minecraft handles the hand, GUI, items, creative inventory, mobs, armor, elytra, fireworks, sounds, walking and breaking particles. It is pinned to Minecraft1.21.1 / Fabric0.19.5 because the upstream bridge targets that API. Newer1.21.11-specific items are not included in this first bridge version.

**Status: user confirmed the Minecraft view, colors, controls, performance and idle behavior work. Native Big Walk object interaction is added and compiles; action lifecycle and protocol tests pass. Live prop/switch/puzzle checks remain.** The previous working character/hotbar prototype remains available.

## Prepare on this computer

1. In File Explorer, open this project's outputs/BigWalkCraftBridge folder.
2. Double-click Prepare-Real-Minecraft.cmd. It uses the prepared local Java and Gradle tools. The first build downloads the required official Minecraft/Fabric files into the private build cache. Wait for PREPARATION COMPLETE.
3. Close both games, keep Steam open, then double-click Launch-Real-Minecraft-Big-Walk.cmd. Keep its window open.
4. Enter a solo Big Walk save normally. Minecraft should automatically open the private bridge world and align its view with Big Walk.
5. E opens the actual Minecraft inventory. F5 switches Minecraft views. F8 hands controls back to Big Walk; F8 in Big Walk returns to Minecraft. Use Minecraft's own creative inventory for spawn eggs, armor, elytra and rockets.

Preparation must run from File Explorer: Java's ZIP file system sees the assistant's restricted build directory as read-only despite ordinary writes succeeding. Running the normal Windows preparation file does not change security settings.

## Verify before calling it working

- The real Minecraft hand/hotbar appears over Big Walk rather than a separate Minecraft landscape.
- Walk and turn: scenery and Minecraft content line up, with working ground collision.
- Place/break a block: original sounds, particles and hand animation appear.
- Spawn a cow, equip armor, and test elytra plus rocket.
- A Minecraft block behind a Big Walk wall is occluded.
- F8 restores native Big Walk controls. Save/reload retains Minecraft content in its own save.

If a step fails, leave the launcher open and report what appeared. Build log: work/bridge/guest-build-normal.log; guest launch log: work/bridge/guest-runtime-normal.log; host log: work/lab/Big Walk/BepInEx/LogOutput.log.

## Saves and rollback

The original Steam game installation is untouched. This uses the existing private test copy and a separate private Minecraft save under work/bridge/minecraft-run. Each Big Walk save receives a distinct Minecraft region. Old prototype blocks remain in their original mod save. To return to the verified custom prototype, close both games and run outputs/BigWalkCraft/Launch-BigWalkCraft.cmd. The launchers disable the other mod before installing their own DLL. No game assets are included in this folder.

## Current limits

Terrain and frame synchronization need live testing. CPU frame transfer may require tuning. Big Walk scenery is preserved and cannot be mined. Big Walk NPC combat is not bridged: Minecraft mobs use Minecraft rules, but do not gain automatic interaction with native Big Walk characters. Multiplayer is disabled. The native compositor currently allocates at the initial Big Walk window resolution; restart both processes after changing resolution. The launcher uses windowed Direct3D11 for the transparent input layer.

Guest code adapted from siddoff/Minecraft-Ring and justbustin/minecraft-crossover-bridge under MIT; see LICENSE-guest.txt and THIRD-PARTY-NOTICES.md. Ownership and transport are recorded in docs/CONTRACT.md.

Performance: transfer width and height default to half the input window (75% fewer bytes). This softens Minecraft content while leaving Big Walk resolution and input coordinates unchanged. Private guest uses view distance6, simulation4, vsync off and a45-60fps capture budget. Host health log includes capture-to-compositor frame age; this excludes monitor presentation and input sampling.

## Big Walk objects and puzzles

- Aim at a native object and press **R** to pick it up or interact. Hold R for a held switch; releasing R releases it.
- **V** uses a held Big Walk object's own action; hold/release is forwarded when supported.
- **G** drops the native object. Minecraft's Q still drops Minecraft items.
- Native objects can be placed in valid puzzle slots using R. The game's own target conditions, key requirements, actions and save handling are retained.
- An interaction prompt appears under Minecraft's crosshair when a valid native target is available. Key bindings are configurable in Minecraft's Controls.
- For climbing, seated actions, native text/menu screens, throws requiring native wind-up, or hand gestures, use **F8** for Big Walk controls, then F8 to return. Native physical pose movement is not simulated by the guest bridge.

Interaction lifecycle releases momentary switches on key up, menu, F8, range loss or lost guest heartbeat. These paths pass bridge tests; puzzle scene behavior must still be verified in game.
