using System;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.Cryptography;
using System.Text;
using BepInEx;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BigWalkMinecraftBridge;

[BepInPlugin("local.bigwalk.minecraft.bridge","BigWalkCraft Real Minecraft Bridge","0.4.0")]
public sealed class BridgePlugin:BasePlugin
{
    internal static BridgePlugin Instance=null!;
    internal static BridgeController? Bridge;
    public override void Load()
    {
        Instance=this;Bridge=new BridgeController();AddComponent<BridgeDriver>();
        new Harmony("local.bigwalk.minecraft.bridge").PatchAll();
        Log.LogInfo("Real Minecraft bridge 0.4.0 loaded. Guest owns all Minecraft item behavior.");
    }
}
public sealed class BridgeDriver:MonoBehaviour
{
    public BridgeDriver(IntPtr p):base(p){}
    private void Update()=>BridgePlugin.Bridge?.Tick();
    private void LateUpdate()=>BridgePlugin.Bridge?.LateTick();
    private void OnDestroy()=>BridgePlugin.Bridge?.Dispose();
}
[HarmonyPatch(typeof(PlayerDecisions),nameof(PlayerDecisions.Update))]
internal static class BridgeHands
{
    static bool Prefix(PlayerDecisions __instance)=>BridgePlugin.Bridge?.Driving!=true || BridgePlugin.Bridge.Player?.decisions?.Pointer!=__instance.Pointer;
}
// The background host must not overwrite GLFW's process-global mouse clipping.
[HarmonyPatch(typeof(CursorManager),nameof(CursorManager.SetLocked))]
internal static class BridgeCursorLock
{
    static bool Prefix()=>BridgePlugin.Bridge?.GuestOwnsInput!=true;
}
[HarmonyPatch(typeof(CursorManager),nameof(CursorManager.SetFree))]
internal static class BridgeCursorFree
{
    static bool Prefix()=>BridgePlugin.Bridge?.GuestOwnsInput!=true;
}
[HarmonyPatch(typeof(PlayerSleeper),nameof(PlayerSleeper.Update))]
internal static class BridgeWake
{
    static void Prefix(PlayerSleeper __instance)
    {
        var b=BridgePlugin.Bridge;
        if(b?.GuestOwnsInput==true && b.Player?.Pointer==__instance.playerCharacter?.Pointer)__instance.RecordAction();
    }
}
[HarmonyPatch(typeof(PlayerCharacter),"LateUpdate")]
internal static class BridgeCamera
{
    static void Postfix(PlayerCharacter __instance) { var b=BridgePlugin.Bridge;if(b?.Player?.Pointer==__instance.Pointer)b.ApplyPose(); }
}
internal sealed class BridgeController:IDisposable
{
    private readonly MemoryMappedFile _file;
    private readonly MemoryMappedViewAccessor _memory;
    private readonly string _runtime;
    private readonly NativeInteractions _interactions;
    internal PlayerCharacter? Player;
    private Camera? _camera;
    private long _frame,_lastGuest,_guestChangedAt,_poseFrame;
    private int _stateSeq,_stage,_life,_switch,_rayRequest,_rayIndex,_rayCount;
    private string _world="";
    private readonly Dictionary<IntPtr,(Renderer renderer,bool enabled)> _renderers=new();
    private bool _driving,_oldKinematic,_oldBackground,_kinematicChanged,_compositorReady,_disposed;
    private Vector3 _bodyOffset,_posePosition,_poseTarget,_poseUp,_feet;
    private float _poseFov;
    private float _nextLog,_nextRendererAttempt,_oldFov;
    private int _rendererAttempts;
    private int _controlFlags;
    private GameObject? _canvasRoot;
    private RawImage? _image;
    private Texture2D? _output,_deviceSeed;
    private IntPtr _nativeLibrary,_renderEvent;
    private NativeCreate? _create;
    private NativeSetFrame? _setFrame;
    private NativeStatus? _nativeStatus;
    private NativeAge? _nativeAge;
    private Il2CppSystem.Action<ScriptableRenderContext,Camera>? _endCamera;
    internal bool Driving=>_driving;
    internal bool GuestOwnsInput=>_guestOwnsInput;
    private bool _guestOwnsInput;
    private CursorLockMode _priorCursorLock;
    private bool _priorCursorVisible;
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate IntPtr NativeCreate(IntPtr deviceTexture,[MarshalAs(UnmanagedType.LPWStr)] string framePath,int width,int height);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate void NativeSetFrame(long frame,IntPtr hostDepth,float z,float w,int active);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate IntPtr NativeEvent();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int NativeStatus();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate long NativeAge();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int NativeDestination(IntPtr texture);
    [StructLayout(LayoutKind.Sequential)] private struct Point { public int x,y; }
    [StructLayout(LayoutKind.Sequential)] private struct WinRect { public int left,top,right,bottom; }
    [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr hwnd,out WinRect rect);
    [DllImport("user32.dll")] private static extern bool ClientToScreen(IntPtr hwnd,ref Point point);
    public BridgeController()
    {
        _runtime=Environment.GetEnvironmentVariable("BWMC_DIR")??Path.GetFullPath(Path.Combine(Paths.ConfigPath,"BigWalkCraftBridge","runtime"));
        Directory.CreateDirectory(_runtime);string path=Path.Combine(_runtime,"bridge.shm");
        var backing=new FileStream(path,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete);
        backing.SetLength(Protocol.SHM_SIZE);
        _file=MemoryMappedFile.CreateFromFile(backing,null,Protocol.SHM_SIZE,MemoryMappedFileAccess.ReadWrite,HandleInheritability.None,false);
        _memory=_file.CreateViewAccessor();
        // A new host generation invalidates stale controls without erasing guest files.
        _memory.Write(Protocol.H_MAGIC,Protocol.MAGIC);_memory.Write(Protocol.H_VERSION,Protocol.VERSION);_memory.Write(Protocol.H_SIZE,Protocol.SHM_SIZE);
        _memory.Write(Protocol.H_HOST_PID,Environment.ProcessId);_memory.Write(Protocol.H_HOST_START,DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        _memory.Write(Protocol.OFF_CONTROL+Protocol.C_FLAGS,0);_memory.Write(Protocol.OFF_STATE+Protocol.S_SEQ,0);
        _memory.Write(Protocol.OFF_RAYS+Protocol.R_RESP_SEQ,_memory.ReadInt32(Protocol.OFF_RAYS+Protocol.R_REQ_SEQ));
        _interactions=new NativeInteractions(this,_memory);
        _oldBackground=Application.runInBackground;Application.runInBackground=true;
        BridgePlugin.Instance.Log.LogInfo("Host mapping ready: "+path);
    }
    internal void Tick()
    {
        if(_disposed)return;
        try
        {
            RefreshPlayer();
            if(Input.GetKeyDown(KeyCode.F8) && !_driving) { _switch++;_memory.Write(Protocol.H_MC_SWITCH_REQ,_switch);_life++;_memory.Write(Protocol.H_HOST_LIFE,_life); }
            long guest=_memory.ReadInt64(Protocol.H_MC_HEARTBEAT),now=Environment.TickCount64;
            if(guest!=_lastGuest) { _lastGuest=guest;_guestChangedAt=now; }
            bool alive=_guestChangedAt!=0 && now-_guestChangedAt<2000;
            ReadControl();
            SetInputOwner(alive && Player!=null && (_controlFlags&Protocol.CTRL_OVERRIDE_CAMERA)!=0);
            bool want=alive && Player!=null && _camera!=null && WorldManager.isReadyForEffects && !Player.menu.localHasMenuOpen && !Player.menu.localHasSteamOverlay && (_controlFlags&Protocol.CTRL_OVERRIDE_CAMERA)!=0;
            SetDriving(want);
            _interactions.Tick(want);
            ProcessRays();
            if(Player!=null && !_compositorReady && _rendererAttempts<3 && Time.unscaledTime>=_nextRendererAttempt)
            {
                _rendererAttempts++;_nextRendererAttempt=Time.unscaledTime+5;
                try { PrepareCompositor(); } catch(Exception e) { BridgePlugin.Instance.Log.LogError("Compositor initialization attempt "+_rendererAttempts+": "+e); }
            }
            PublishState();
            if(Time.unscaledTime>=_nextLog) { _nextLog=Time.unscaledTime+10;BridgePlugin.Instance.Log.LogInfo($"Bridge: host={Player!=null}, guest={alive}, driving={_driving}, stage={_stage}, rays={_rayIndex}/{_rayCount}, renderer={_nativeStatus?.Invoke()??0}, guest-frame={_poseFrame}, frame-age-ms={_nativeAge?.Invoke()??-1}"); }
        }
        catch(Exception e) { SetInputOwner(false);SetDriving(false);BridgePlugin.Instance.Log.LogError(e);_nextLog=Time.unscaledTime+10; }
    }
    private void RefreshPlayer()
    {
        var p=WorldManager.localPlayerCharacter;
        bool solo=PlayerCharacter.allPlayerCharacters==null || PlayerCharacter.allPlayerCharacters.Count<=1;
        if(!solo)p=null;
        string world=p==null?"":SaveManager.instance?.currentData?.filenameUid??"";
        if(Player?.Pointer==p?.Pointer && _world==world)return;
        _interactions.Release();SetDriving(false);RestoreRenderers();Player=p;_world=world;_camera=p?.cameraMinder?.playerCameraReferences?.playerCamera;
        if(p==null)return;
        byte[] hash=SHA256.HashData(Encoding.UTF8.GetBytes(string.IsNullOrEmpty(world)?"unsaved":world));
        _stage=BitConverter.ToInt32(hash,0)&0x7fffffff;if(_stage==0)_stage=1;
        _life++;_memory.Write(Protocol.H_HOST_LIFE,_life);
        var root=p.kernal??p.transform;_bodyOffset=p.rb!=null?p.rb.position-root.position:Vector3.zero;
        foreach(var rows in new[]{p.looks.headRenderers,p.looks.torsoRenderers,p.looks.legsRenderers})
            if(rows!=null)foreach(var row in rows)if(row?.renderer!=null)_renderers.TryAdd(row.renderer.Pointer,(row.renderer,row.renderer.enabled));
        _camera!.depthTextureMode|=DepthTextureMode.Depth;
        // URP per-camera depth must be requested explicitly when that component exists.
        var additional=_camera.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
        if(additional!=null)additional.requiresDepthTexture=true;
        BridgePlugin.Instance.Log.LogInfo($"Solo world attached. stage={_stage}, life={_life}, body-offset={_bodyOffset}");
    }
    private void SetInputOwner(bool guest)
    {
        if(guest==_guestOwnsInput)return;
        if(guest) { _priorCursorLock=Cursor.lockState;_priorCursorVisible=Cursor.visible;Cursor.lockState=CursorLockMode.None;Cursor.visible=true; }
        else { Cursor.lockState=_priorCursorLock;Cursor.visible=_priorCursorVisible; }
        _guestOwnsInput=guest;
        BridgePlugin.Instance.Log.LogInfo(guest?"Cursor owner -> Minecraft":"Cursor owner -> Big Walk");
    }
    private void SetDriving(bool value)
    {
        if(value==_driving)return;
        if(!value)_interactions.Release();
        _driving=value;
        if(_camera!=null) { if(value)_oldFov=_camera.fieldOfView;else _camera.fieldOfView=_oldFov; }
        if(Player?.rb!=null)
        {
            if(value) { _oldKinematic=Player.rb.isKinematic;_kinematicChanged=true;Player.rb.isKinematic=true; }
            else if(_kinematicChanged) { Player.rb.isKinematic=_oldKinematic;_kinematicChanged=false; }
        }
        foreach(var pair in _renderers.Values)if(pair.renderer!=null)pair.renderer.enabled=value?false:pair.enabled;
        if(_image!=null)_image.gameObject.SetActive(value);
        BridgePlugin.Instance.Log.LogInfo(value?"Control -> real Minecraft":"Control -> Big Walk");
    }
    private void RestoreRenderers() { foreach(var pair in _renderers.Values)if(pair.renderer!=null)pair.renderer.enabled=pair.enabled;_renderers.Clear(); }
    private Vector3 Vector(long offset)=>new(_memory.ReadSingle(offset),_memory.ReadSingle(offset+4),_memory.ReadSingle(offset+8));
    private void Vector(long offset,Vector3 v) { _memory.Write(offset,v.x);_memory.Write(offset+4,v.y);_memory.Write(offset+8,v.z); }
    private void ReadControl()
    {
        int b=Protocol.OFF_CONTROL,s=_memory.ReadInt32(b+Protocol.C_SEQ);if(s==0 || (s&1)!=0)return;
        int flags=_memory.ReadInt32(b+Protocol.C_FLAGS);long frame=_memory.ReadInt64(b+Protocol.C_MC_FRAME);
        var position=Vector(b+Protocol.C_CAM_POS);var target=Vector(b+Protocol.C_CAM_TARGET);var up=Vector(b+Protocol.C_CAM_UP);var feet=Vector(b+Protocol.C_HUNTER_POS);float fov=_memory.ReadSingle(b+Protocol.C_FOVY);
        Thread.MemoryBarrier();if(s!=_memory.ReadInt32(b+Protocol.C_SEQ))return;
        if(!Finite(position)||!Finite(target)||!Finite(feet)||!float.IsFinite(fov)||fov<10||fov>160)return;
        _controlFlags=flags;_poseFrame=frame;_posePosition=position;_poseTarget=target;_poseUp=up;_feet=feet;_poseFov=fov;
    }
    private static bool Finite(Vector3 p)=>float.IsFinite(p.x)&&float.IsFinite(p.y)&&float.IsFinite(p.z)&&Math.Abs(p.x)<1000000&&Math.Abs(p.y)<1000000&&Math.Abs(p.z)<1000000;
    internal void ApplyPose()
    {
        if(!_driving || _camera==null || Player==null)return;
        if((_poseTarget-_posePosition).sqrMagnitude<.01f)return;
        var direction=_poseTarget-_posePosition;
        var body=Player.kernal??Player.transform;
        if(direction.x*direction.x+direction.z*direction.z>.001f)body.rotation=Quaternion.Euler(0,(float)Math.Atan2(direction.x,direction.z)*Mathf.Rad2Deg,0);
        if(Player.rb!=null)Player.rb.position=_feet+_bodyOffset;
        else (Player.kernal??Player.transform).position=_feet;
        if(Player.cameraTransform!=null && Player.cameraTransform.Pointer!=_camera.transform.Pointer) { Player.cameraTransform.position=_posePosition;Player.cameraTransform.rotation=Quaternion.LookRotation(direction.normalized,_poseUp.normalized); }
        _camera.transform.position=_posePosition;_camera.transform.rotation=Quaternion.LookRotation((_poseTarget-_posePosition).normalized,_poseUp.normalized);_camera.fieldOfView=_poseFov;
        foreach(var pair in _renderers.Values)if(pair.renderer!=null)pair.renderer.enabled=false;
    }
    internal void LateTick() { ApplyPose(); }
    private void PublishState()
    {
        int b=Protocol.OFF_STATE;_memory.Write(b+Protocol.S_SEQ,++_stateSeq);Thread.MemoryBarrier();
        int flags=Protocol.STATE_WINDOW_VALID;
        if(_camera!=null)flags|=Protocol.STATE_CAMERA_VALID;
        if(Player!=null && WorldManager.isReadyForEffects)flags|=Protocol.STATE_PLAYER_VALID;
        else flags|=Protocol.STATE_HOST_BUSY;
        if(_driving)flags|=Protocol.STATE_CAM_OVERRIDDEN;
        if(_compositorReady)flags|=Protocol.STATE_COMPOSITING;
        flags|=Protocol.STATE_WINDOW_FOCUSED;
        _memory.Write(b+Protocol.S_FLAGS,flags);_memory.Write(b+Protocol.S_FRAME,++_frame);
        if(_camera!=null) { Vector(b+Protocol.S_CAM_POS,_camera.transform.position);Vector(b+Protocol.S_CAM_TARGET,_camera.transform.position+_camera.transform.forward);Vector(b+Protocol.S_CAM_UP,_camera.transform.up);_memory.Write(b+Protocol.S_FOVY,_camera.fieldOfView);_memory.Write(b+Protocol.S_NEAR,_camera.nearClipPlane);_memory.Write(b+Protocol.S_FAR,_camera.farClipPlane);_memory.Write(b+Protocol.S_ASPECT,_camera.aspect); }
        _memory.Write(b+Protocol.S_UNITS_PER_METER,1f);
        if(Player!=null) { var body=Player.kernal??Player.transform;Vector(b+Protocol.S_PLAYER_POS,body.position);var q=Quaternion.Euler(0,(_camera?.transform.eulerAngles.y??body.eulerAngles.y)+180,0);_memory.Write(b+Protocol.S_PLAYER_QUAT,q.x);_memory.Write(b+Protocol.S_PLAYER_QUAT+4,q.y);_memory.Write(b+Protocol.S_PLAYER_QUAT+8,q.z);_memory.Write(b+Protocol.S_PLAYER_QUAT+12,q.w); }
        IntPtr hwnd=Process.GetCurrentProcess().MainWindowHandle;GetClientRect(hwnd,out var rect);var point=new Point();ClientToScreen(hwnd,ref point);
        _memory.Write(b+Protocol.S_WIN,point.x);_memory.Write(b+Protocol.S_WIN+4,point.y);_memory.Write(b+Protocol.S_WIN+8,rect.right-rect.left);_memory.Write(b+Protocol.S_WIN+12,rect.bottom-rect.top);
        _memory.Write(b+Protocol.S_BB,Screen.width);_memory.Write(b+Protocol.S_BB+4,Screen.height);_memory.Write(b+Protocol.S_STAGE,_stage);
        Thread.MemoryBarrier();_memory.Write(b+Protocol.S_SEQ,++_stateSeq);_memory.Write(Protocol.H_HOST_HEARTBEAT,_frame);
    }
    private void ProcessRays()
    {
        int b=Protocol.OFF_RAYS,req=_memory.ReadInt32(b+Protocol.R_REQ_SEQ);
        if(req==_memory.ReadInt32(b+Protocol.R_RESP_SEQ))return;
        if(req!=_rayRequest) { _rayRequest=req;_rayIndex=0;_rayCount=Math.Clamp(_memory.ReadInt32(b+Protocol.R_COUNT),0,Protocol.MAX_RAYS); }
        // Yield between ray groups; complete only a whole request. Skip the hidden player.
        int end=Math.Min(_rayCount,_rayIndex+256);
        for(;_rayIndex<end;_rayIndex++)
        {
            long input=b+Protocol.R_RAYS+_rayIndex*Protocol.RAY_SIZE,output=b+Protocol.R_HITS+_rayIndex*Protocol.HIT_SIZE;
            var start=Vector(input);var finish=Vector(input+12);var delta=finish-start;RaycastHit? chosen=null;
            if(Finite(start)&&Finite(finish)&&delta.magnitude>.0001f&&delta.magnitude<10000)
                foreach(var hit in Physics.RaycastAll(start,delta.normalized,delta.magnitude,~0,QueryTriggerInteraction.Ignore).OrderBy(h=>h.distance))
                { if(hit.collider==null || Player!=null && (hit.collider.transform.IsChildOf(Player.transform) || hit.collider.attachedRigidbody?.Pointer==Player.rb?.Pointer))continue;chosen=hit;break; }
            Vector(output,chosen?.point??finish);Vector(output+12,chosen?.normal??Vector3.up);_memory.Write(output+24,chosen.HasValue?1:0);_memory.Write(output+28,0);
        }
        _memory.Write(b+Protocol.R_PROCESSED,_rayIndex);
        if(_rayIndex==_rayCount) { Thread.MemoryBarrier();_memory.Write(b+Protocol.R_RESP_SEQ,_rayRequest); }
    }
    private T Native<T>(string name)where T:Delegate=>Marshal.GetDelegateForFunctionPointer<T>(NativeLibrary.GetExport(_nativeLibrary,name));
    private void PrepareCompositor()
    {
        if(SystemInfo.graphicsDeviceType!=GraphicsDeviceType.Direct3D11)throw new NotSupportedException("Bridge requires Direct3D11. Start the test game with -force-d3d11.");
        string folder=Path.GetDirectoryName(typeof(BridgePlugin).Assembly.Location)!;
        if(_nativeLibrary==IntPtr.Zero) { _nativeLibrary=NativeLibrary.Load(Path.Combine(folder,"BigWalkMinecraftRenderer.dll"));_create=Native<NativeCreate>("BWMC_Create");_setFrame=Native<NativeSetFrame>("BWMC_SetFrame");_renderEvent=Native<NativeEvent>("BWMC_GetRenderEvent")();_nativeStatus=Native<NativeStatus>("BWMC_Status");_nativeAge=Native<NativeAge>("BWMC_FrameAgeMs"); }
        _deviceSeed=new Texture2D(2,2,TextureFormat.RGBA32,false);_deviceSeed.Apply();
        IntPtr texture=_create!(_deviceSeed.GetNativeTexturePtr(),Path.Combine(_runtime,"frames.shm"),Screen.width,Screen.height);
        if(texture==IntPtr.Zero)throw new InvalidOperationException("Native compositor initialization failed: "+_nativeStatus!());
        _output=new Texture2D(Screen.width,Screen.height,TextureFormat.RGBA32,false);_output.Apply();
        int destination=Native<NativeDestination>("BWMC_SetDestination")(_output.GetNativeTexturePtr());
        if(destination!=1)throw new InvalidOperationException("Unity output texture rejected: "+destination);
        _canvasRoot=new GameObject("Real Minecraft frame compositor");var canvas=_canvasRoot.AddComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=30000;
        var go=new GameObject("Minecraft world, hand and HUD");go.AddComponent<RectTransform>();go.transform.SetParent(_canvasRoot.transform,false);_image=go.AddComponent<RawImage>();_image.raycastTarget=false;_image.texture=_output;_image.uvRect=new Rect(0,1,1,-1);var rt=_image.rectTransform;rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.offsetMin=Vector2.zero;rt.offsetMax=Vector2.zero;
        _endCamera=(Il2CppSystem.Action<ScriptableRenderContext,Camera>)new Action<ScriptableRenderContext,Camera>(EndCamera);
        RenderPipelineManager.add_endCameraRendering(_endCamera);
        _compositorReady=true;go.SetActive(false);BridgePlugin.Instance.Log.LogInfo("Native D3D11 compositor initialized.");
    }
    private void EndCamera(ScriptableRenderContext context,Camera camera)
    {
        if(!_compositorReady || camera.Pointer!=_camera?.Pointer)return;
        var depth=Shader.GetGlobalTexture("_CameraDepthTexture");var z=Shader.GetGlobalVector("_ZBufferParams");
        _setFrame!(_poseFrame,depth?.GetNativeTexturePtr()??IntPtr.Zero,z.z,z.w,_driving?1:0);
        GL.IssuePluginEvent(_renderEvent,1);
    }
    public void Dispose()
    {
        if(_disposed)return;_disposed=true;_interactions.Release();SetInputOwner(false);SetDriving(false);RestoreRenderers();
        if(_endCamera!=null)RenderPipelineManager.remove_endCameraRendering(_endCamera);
        if(_canvasRoot!=null)Object.Destroy(_canvasRoot);if(_output!=null)Object.Destroy(_output);if(_deviceSeed!=null)Object.Destroy(_deviceSeed);
        Application.runInBackground=_oldBackground;_memory.Write(Protocol.H_HOST_HEARTBEAT,0L);_memory.Dispose();_file.Dispose();
        // Native textures and render callback remain valid until the process exits.
        // Never unload a library while Unity's render thread can still hold its callback.
    }
}
