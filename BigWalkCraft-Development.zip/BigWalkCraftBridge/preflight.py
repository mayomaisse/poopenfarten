from pathlib import Path
import json,re
root=Path(__file__).parent
checks=[];errors=[]
for path in sorted((root/'sheets').glob('*.json')):
 sheet=json.loads(path.read_text());ids=set()
 for row in sheet['rows']:
  if row['id'] in ids:errors.append('duplicate '+row['id'])
  ids.add(row['id'])
  for col in sheet['columns']:
   okay=row.get(col) is not None and row.get(col)!='';checks.append(dict(sheet=path.stem,row=row['id'],column=col,checked=okay))
   if not okay:errors.append('unfilled '+row['id']+'.'+col)
  if set(row)!=set(sheet['columns']):errors.append('column mismatch '+row['id'])
 if not sheet.get('evidence'):errors.append('no evidence '+path.name)
java=(root/'guest/src/main/java/dev/ermc/bridge/link/Protocol.java').read_text()
cs=(root/'host/Protocol.cs').read_text()
for name,value in re.findall(r'public static final int (\w+)\s*=\s*([^;]+);',java):
 okay=('internal const int '+name+' = '+value+';') in cs
 checks.append(dict(sheet='protocol',row=name,column='shared_value',checked=okay))
 if not okay:errors.append('protocol mismatch '+name)
required=['docs/CONTRACT.md','LICENSE-guest.txt','host/BridgePlugin.cs','host/NativeInteractions.cs','native/renderer.cpp','guest/src/main/resources/fabric.mod.json']
for file in required:
 okay=(root/file).exists();checks.append(dict(sheet='build',row=file,column='exists',checked=okay))
 if not okay:errors.append('missing '+file)
report=dict(clean=not errors,cells=len(checks),checks=checks,errors=errors,scope='Design and bridge protocol preflight; live two-game checks required separately')
(root/'preflight-report.json').write_text(json.dumps(report,indent=2))
if errors:raise SystemExit('\n'.join(errors))
print('Bridge preflight clean:',len(checks),'cells/contract/protocol checks')
