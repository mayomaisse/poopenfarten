// BigWalkCraft native D3D11 compositor. Game assets are supplied by the live guest.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <algorithm>

template<class T> static void drop(T*& p){if(p){p->Release();p=nullptr;}}
static ID3D11Device* device;
static ID3D11Texture2D* output;
static ID3D11Texture2D* destination;
static ID3D11RenderTargetView* target;
static ID3D11VertexShader* vertex;
static ID3D11PixelShader* pixel;
static ID3D11SamplerState* sampler;
static ID3D11Buffer* constants;
static ID3D11RasterizerState* raster;
static ID3D11BlendState* blend;
static ID3D11DepthStencilState* noDepth;
static ID3D11Texture2D* layers[4];
static ID3D11ShaderResourceView* views[4];
static ID3D11ShaderResourceView* hostView;
static ID3D11Resource* hostResource;
static int outputW,outputH,inputW,inputH,status;
static HANDLE frameFile=INVALID_HANDLE_VALUE,frameMapping;
static unsigned char* frames;
static std::wstring framePath;
static SRWLOCK gate=SRWLOCK_INIT;
static uint64_t wantedFrame,lastFrame;
static volatile LONG64 frameAgeMs=-1;
static ID3D11Texture2D* pendingDepth;
static float pendingZ,pendingW;
static bool active;
static constexpr uint64_t SLOT_BYTES=0x100ull+3840ull*2160ull*16ull;
static constexpr uint64_t FILE_BYTES=0x1000ull+SLOT_BYTES*3;
struct Parameters{float nearZ,farZ,z,w;float hasDepth,hasHand,pad1,pad2;};
static const char* shader=R"HLSL(
Texture2D<float4> worldColor:register(t0);
Texture2D<float> worldDepth:register(t1);
Texture2D<float4> handColor:register(t2);
Texture2D<float4> hudColor:register(t3);
Texture2D<float> hostDepth:register(t4);
SamplerState nearest:register(s0);
cbuffer Params:register(b0){float nearZ,farZ,z,w;float hasDepth,hasHand,pad1,pad2;};
struct V {float4 position:SV_POSITION;float2 uv:TEXCOORD0;};
V vs(uint index:SV_VertexID){V o;float2 uv=float2((index<<1)&2,index&2);o.position=float4(uv*float2(2,-2)+float2(-1,1),0,1);o.uv=uv;return o;}
float4 over(float4 a,float4 b){float alpha=a.a+b.a*(1-a.a);if(alpha<.002)return 0;return float4((a.rgb*a.a+b.rgb*b.a*(1-a.a))/alpha,alpha);}
float4 ps(V v):SV_TARGET {
 float2 guestUv=float2(v.uv.x,1-v.uv.y);
 float depth=worldDepth.SampleLevel(nearest,guestUv,0);
 float4 color=worldColor.SampleLevel(nearest,guestUv,0);
 if(depth>=.999999 || color.a<.02)color=0;
 else if(hasDepth>.5){
  float guestLinear=(2*nearZ*farZ)/(farZ+nearZ-(depth*2-1)*(farZ-nearZ));
  float raw=hostDepth.SampleLevel(nearest,v.uv,0);
  float denominator=z*raw+w;
  float hostLinear=denominator>1e-8?1/denominator:1e10;
  if(guestLinear>hostLinear+.12)color=0;
 }
 float4 hand=hasHand>.5?handColor.SampleLevel(nearest,guestUv,0):float4(0,0,0,0);
 float4 hud=hudColor.SampleLevel(nearest,guestUv,0);
 if(hand.a<.02)hand=0;if(hud.a<.02)hud=0;
 return over(hud,over(hand,color));
}
)HLSL";

static bool makeLayers(int w,int h){
 for(int i=0;i<4;i++){drop(views[i]);drop(layers[i]);
  D3D11_TEXTURE2D_DESC d={};d.Width=w;d.Height=h;d.MipLevels=d.ArraySize=1;
  d.Format=i==1?DXGI_FORMAT_R32_FLOAT:DXGI_FORMAT_B8G8R8A8_UNORM;d.SampleDesc.Count=1;d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=D3D11_BIND_SHADER_RESOURCE;
  if(FAILED(device->CreateTexture2D(&d,nullptr,&layers[i]))||FAILED(device->CreateShaderResourceView(layers[i],nullptr,&views[i]))){status=-20;return false;}
 }inputW=w;inputH=h;return true;
}
static bool openFrames(){
 if(frames)return true;
 frameFile=CreateFileW(framePath.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(frameFile==INVALID_HANDLE_VALUE)return false;
 LARGE_INTEGER size;if(!GetFileSizeEx(frameFile,&size)||uint64_t(size.QuadPart)<FILE_BYTES){CloseHandle(frameFile);frameFile=INVALID_HANDLE_VALUE;return false;}
 frameMapping=CreateFileMappingW(frameFile,nullptr,PAGE_READONLY,0,0,nullptr);
 frames=(unsigned char*)MapViewOfFile(frameMapping,FILE_MAP_READ,0,0,FILE_BYTES);
 if(!frames){if(frameMapping)CloseHandle(frameMapping);CloseHandle(frameFile);frameFile=INVALID_HANDLE_VALUE;return false;}
 return true;
}
static bool updateHostDepth(ID3D11Texture2D* texture){
 if(texture==hostResource)return hostView!=nullptr;
 drop(hostView);drop(hostResource);
 if(!texture)return false;
 D3D11_TEXTURE2D_DESC td;texture->GetDesc(&td);
 if(!(td.BindFlags&D3D11_BIND_SHADER_RESOURCE)||td.SampleDesc.Count!=1)return false;
 D3D11_SHADER_RESOURCE_VIEW_DESC sd={};sd.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D;sd.Texture2D.MipLevels=1;
 sd.Format=td.Format==DXGI_FORMAT_R32_TYPELESS?DXGI_FORMAT_R32_FLOAT:td.Format==DXGI_FORMAT_R24G8_TYPELESS?DXGI_FORMAT_R24_UNORM_X8_TYPELESS:td.Format==DXGI_FORMAT_R16_TYPELESS?DXGI_FORMAT_R16_UNORM:td.Format;
 if(FAILED(device->CreateShaderResourceView(texture,&sd,&hostView)))return false;
 hostResource=texture;hostResource->AddRef();return true;
}
extern "C" __declspec(dllexport) void* BWMC_Create(void* texture,const wchar_t* path,int w,int h){
 if(output)return output;
 if(!texture||w<1||h<1||w>3840||h>2160){status=-1;return nullptr;}
 auto* resource=(ID3D11Resource*)texture;resource->GetDevice(&device);
 if(!device){status=-2;return nullptr;}
 framePath=path;outputW=w;outputH=h;
 D3D11_TEXTURE2D_DESC td={};td.Width=w;td.Height=h;td.MipLevels=td.ArraySize=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.SampleDesc.Count=1;td.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
 if(FAILED(device->CreateTexture2D(&td,nullptr,&output))||FAILED(device->CreateRenderTargetView(output,nullptr,&target))){status=-3;return nullptr;}
 ID3DBlob* code=nullptr,*error=nullptr;
 HRESULT hr=D3DCompile(shader,std::strlen(shader),"BWMC compositor",nullptr,nullptr,"vs","vs_5_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);drop(error);
 if(FAILED(hr)||FAILED(device->CreateVertexShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&vertex))){drop(code);status=-4;return nullptr;}drop(code);
 hr=D3DCompile(shader,std::strlen(shader),"BWMC compositor",nullptr,nullptr,"ps","ps_5_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);drop(error);
 if(FAILED(hr)||FAILED(device->CreatePixelShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&pixel))){drop(code);status=-5;return nullptr;}drop(code);
 D3D11_SAMPLER_DESC sd={};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;
 if(FAILED(device->CreateSamplerState(&sd,&sampler))){status=-6;return nullptr;}
 D3D11_BUFFER_DESC bd={};bd.ByteWidth=sizeof(Parameters);bd.Usage=D3D11_USAGE_DEFAULT;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
 if(FAILED(device->CreateBuffer(&bd,nullptr,&constants))){status=-7;return nullptr;}
 D3D11_RASTERIZER_DESC rd={};rd.FillMode=D3D11_FILL_SOLID;rd.CullMode=D3D11_CULL_NONE;rd.DepthClipEnable=true;
 if(FAILED(device->CreateRasterizerState(&rd,&raster))){status=-8;return nullptr;}
 D3D11_BLEND_DESC bl={};bl.RenderTarget[0].RenderTargetWriteMask=D3D11_COLOR_WRITE_ENABLE_ALL;
 if(FAILED(device->CreateBlendState(&bl,&blend))){status=-9;return nullptr;}
 D3D11_DEPTH_STENCIL_DESC ds={};ds.DepthEnable=false;ds.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ZERO;
 if(FAILED(device->CreateDepthStencilState(&ds,&noDepth))){status=-10;return nullptr;}
 status=1;return output;
}
extern "C" __declspec(dllexport) int BWMC_SetDestination(void* texture){
 if(!texture||!output)return -40;
 auto* next=(ID3D11Texture2D*)texture;D3D11_TEXTURE2D_DESC d;next->GetDesc(&d);
 if(d.Width!=UINT(outputW)||d.Height!=UINT(outputH)||d.MipLevels!=1||d.ArraySize!=1||d.SampleDesc.Count!=1)return -41;
 if(d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM&&d.Format!=DXGI_FORMAT_R8G8B8A8_TYPELESS&&d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB)return -42;
 ID3D11Device* owner=nullptr;next->GetDevice(&owner);bool same=owner==device;drop(owner);if(!same)return -43;
 next->AddRef();drop(destination);destination=next;return 1;
}
static void copyOutput(ID3D11DeviceContext* context){if(destination)context->CopyResource(destination,output);}
extern "C" __declspec(dllexport) void BWMC_SetFrame(int64_t frame,void* depth,float z,float w,int enabled){
 AcquireSRWLockExclusive(&gate);wantedFrame=frame;active=enabled!=0;pendingZ=z;pendingW=w;
 auto* next=(ID3D11Texture2D*)depth;if(next)next->AddRef();drop(pendingDepth);pendingDepth=next;
 ReleaseSRWLockExclusive(&gate);
}
extern "C" __declspec(dllexport) int BWMC_Status(){return status;}
extern "C" __declspec(dllexport) int64_t BWMC_FrameAgeMs(){return InterlockedCompareExchange64(&frameAgeMs,0,0);}
static void __stdcall render(int){
 if(!device||!output)return;
 uint64_t want;bool enabled;float z,w;ID3D11Texture2D* depth;
 AcquireSRWLockShared(&gate);want=wantedFrame;enabled=active;z=pendingZ;w=pendingW;depth=pendingDepth;if(depth)depth->AddRef();ReleaseSRWLockShared(&gate);
 ID3D11DeviceContext* context=nullptr;device->GetImmediateContext(&context);
 const float clear[4]={0,0,0,0};
 if(!enabled){context->ClearRenderTargetView(target,clear);copyOutput(context);drop(depth);drop(context);return;}
 if(!openFrames()){status=2;context->ClearRenderTargetView(target,clear);copyOutput(context);drop(depth);drop(context);return;}
 if(*(uint32_t*)frames!=0x524d484d||*(uint32_t*)(frames+4)!=3){status=-30;drop(depth);drop(context);return;}
 unsigned char* header=nullptr;
 for(int i=0;i<3;i++){auto* h=frames+0x1000+i*SLOT_BYTES;uint32_t seq=*(volatile uint32_t*)h;MemoryBarrier();if(seq&&!(seq&1)&&*(uint64_t*)(h+0x10)==want){header=h;break;}}
 if(!header){status=3;context->ClearRenderTargetView(target,clear);copyOutput(context);drop(depth);drop(context);return;}
 FILETIME nowFile;GetSystemTimeAsFileTime(&nowFile);ULARGE_INTEGER nowTicks;nowTicks.LowPart=nowFile.dwLowDateTime;nowTicks.HighPart=nowFile.dwHighDateTime;
 int64_t stamp=*(int64_t*)(header+0x38),age=int64_t(nowTicks.QuadPart/10000-11644473600000ull)-stamp;
 InterlockedExchange64(&frameAgeMs,stamp>0&&age>=0&&age<15000?age:-1);
 uint32_t seq=*(volatile uint32_t*)header;int width=*(int*)(header+4),height=*(int*)(header+8),flags=*(int*)(header+12);
 if(width<1||height<1||width>3840||height>2160||(flags&8)){status=-31;drop(depth);drop(context);return;}
 if((width!=inputW||height!=inputH)&&!makeLayers(width,height)){drop(depth);drop(context);return;}
 const uint64_t bytes=uint64_t(width)*height*4;
 bool hand=(flags&4)!=0;
 if(want!=lastFrame){
  for(int i=0;i<(hand?4:3);i++)context->UpdateSubresource(layers[i],0,nullptr,header+0x100+bytes*i,width*4,0);
  MemoryBarrier();if(seq!=*(volatile uint32_t*)header){status=4;drop(depth);drop(context);return;}lastFrame=want;
 }
 float nearZ=*(float*)(header+0x20),farZ=*(float*)(header+0x24);
 if(!(nearZ>0&&farZ>nearZ)){status=-32;drop(depth);drop(context);return;}
 bool hasDepth=updateHostDepth(depth);drop(depth);
 Parameters params={nearZ,farZ,z,w,hasDepth?1.f:0.f,hand?1.f:0.f,0,0};
 // Save every D3D state we touch, including all MRTs and viewport/scissor arrays.
 ID3D11RenderTargetView* oldTargets[8]={};ID3D11DepthStencilView* oldDSV=nullptr;context->OMGetRenderTargets(8,oldTargets,&oldDSV);
 ID3D11VertexShader* oldVS=nullptr;ID3D11PixelShader* oldPS=nullptr;ID3D11GeometryShader* oldGS=nullptr;
 ID3D11ClassInstance* vsClasses[256]={},*psClasses[256]={},*gsClasses[256]={};UINT nvs=256,nps=256,ngs=256;
 context->VSGetShader(&oldVS,vsClasses,&nvs);context->PSGetShader(&oldPS,psClasses,&nps);context->GSGetShader(&oldGS,gsClasses,&ngs);
 ID3D11ShaderResourceView* oldResources[5]={};context->PSGetShaderResources(0,5,oldResources);
 ID3D11SamplerState* oldSampler=nullptr;context->PSGetSamplers(0,1,&oldSampler);
 ID3D11Buffer* oldConstant=nullptr;context->PSGetConstantBuffers(0,1,&oldConstant);
 ID3D11InputLayout* oldLayout=nullptr;context->IAGetInputLayout(&oldLayout);D3D11_PRIMITIVE_TOPOLOGY oldTopology;context->IAGetPrimitiveTopology(&oldTopology);
 ID3D11RasterizerState* oldRaster=nullptr;context->RSGetState(&oldRaster);D3D11_VIEWPORT oldViewport[16];UINT viewportCount=16;context->RSGetViewports(&viewportCount,oldViewport);
 ID3D11BlendState* oldBlend=nullptr;float oldFactor[4];UINT oldMask;context->OMGetBlendState(&oldBlend,oldFactor,&oldMask);
 ID3D11DepthStencilState* oldDepth=nullptr;UINT oldRef;context->OMGetDepthStencilState(&oldDepth,&oldRef);
 ID3D11ShaderResourceView* resources[5]={views[0],views[1],hand?views[2]:nullptr,hand?views[3]:views[2],hostView};
 context->OMSetRenderTargets(1,&target,nullptr);context->OMSetBlendState(blend,nullptr,~0u);context->OMSetDepthStencilState(noDepth,0);context->RSSetState(raster);
 D3D11_VIEWPORT viewport={0,0,float(outputW),float(outputH),0,1};context->RSSetViewports(1,&viewport);
 context->IASetInputLayout(nullptr);context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);context->VSSetShader(vertex,nullptr,0);context->PSSetShader(pixel,nullptr,0);context->GSSetShader(nullptr,nullptr,0);
 context->UpdateSubresource(constants,0,nullptr,&params,0,0);context->PSSetConstantBuffers(0,1,&constants);context->PSSetShaderResources(0,5,resources);context->PSSetSamplers(0,1,&sampler);context->Draw(3,0);
 ID3D11ShaderResourceView* empty[5]={};context->PSSetShaderResources(0,5,empty);
 context->OMSetRenderTargets(0,nullptr,nullptr);copyOutput(context);
 context->OMSetRenderTargets(8,oldTargets,oldDSV);context->OMSetBlendState(oldBlend,oldFactor,oldMask);context->OMSetDepthStencilState(oldDepth,oldRef);context->RSSetState(oldRaster);context->RSSetViewports(viewportCount,oldViewport);
 context->IASetInputLayout(oldLayout);context->IASetPrimitiveTopology(oldTopology);context->VSSetShader(oldVS,vsClasses,nvs);context->PSSetShader(oldPS,psClasses,nps);context->GSSetShader(oldGS,gsClasses,ngs);
 context->PSSetConstantBuffers(0,1,&oldConstant);context->PSSetShaderResources(0,5,oldResources);context->PSSetSamplers(0,1,&oldSampler);
 for(auto*& p:oldTargets)drop(p);for(auto*& p:oldResources)drop(p);for(UINT i=0;i<nvs;i++)drop(vsClasses[i]);for(UINT i=0;i<nps;i++)drop(psClasses[i]);for(UINT i=0;i<ngs;i++)drop(gsClasses[i]);
 drop(oldDSV);drop(oldVS);drop(oldPS);drop(oldGS);drop(oldLayout);drop(oldRaster);drop(oldBlend);drop(oldDepth);drop(oldConstant);drop(oldSampler);drop(context);status=hasDepth?10:11;
}
extern "C" __declspec(dllexport) void* BWMC_GetRenderEvent(){return (void*)&render;}
