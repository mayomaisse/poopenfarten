# BigWalkCraft real Minecraft bridge

Route: real Minecraft Java 1.21.1 Fabric guest adapted from siddoff/Minecraft-Ring (MIT), connected to a BepInEx6 IL2CPP host in the private Big Walk 1.6.0 Unity6000.3.17f1 test copy. Guest version is pinned to the tested upstream API. User owns Minecraft Java; runtime game files are acquired by Fabric Loom, never shipped.

Minecraft owns player movement, camera, items, inventory, mobs, armor, elytra, rockets, combat among Minecraft entities, sound, animation, particles and guest saves. Big Walk owns its scenery, NPCs, native interactions and native saves. Its hidden player follows Minecraft only in active solo bridge mode. F8 hands control and camera back to Big Walk; reconnect recalls Minecraft to Big Walk. World/save changes create a distinct host stage.

1 Unity metre = 1 Minecraft block. Host is Unity left-handed, Y up; guest maps x=(hostX-anchorX)+regionX, y=(hostY-anchorY)+100, z=-(hostZ-anchorZ)+0.5. Guest CoordMap is the shared oracle. No host scenery mining. Minecraft-built blocks and spawned entities persist in a separate guest world.

Transport is local file-backed shared memory, little endian. bridge.shm magic0x434d484d version1 size8MiB: host writes seqlock state each frame, reads guest control; guest submits up to8192 rays per batch, host answers bounded batches with Unity physics excluding player. Entities/damage table initially empty: no invented Big Walk enemy damage or loot. frames.shm magic0x524d484d version3: triple-buffered worldRGBA, depthfloat, handRGBA, HUDRGBA. FrameID must match its pose. Newer snapshots supersede old; odd seqlocks are skipped, never spun indefinitely on game main thread.

Rendering: native D3D11 compositor produces an external Unity texture from CPU-captured guest frames, tests guest world depth against Big Walk camera depth, then draws hand/HUD without world occlusion. Three-frame readback is asynchronous upstream. CPU transfer is initial route; shared-GPU path is disabled until independently tested. Native output is drawn via Unity Canvas; empty/loading/stale frames clear output.

Lifecycle: host starts first, publishes identity and heartbeat; guest automatically opens private void world once host is live. A2s stalled peer releases camera and player. Closing/loading Big Walk hides guest output and pauses control; guest save is independent. Stop/restart restores original renderers and rigidbody state. No multiplayer. No patches to original Steam installation. Original custom prototype is preserved for rollback.

First oracle: guest maps host and opens bridge world; real Minecraft hand/HUD appear over Big Walk at matching camera; walk and place/break one block with original sounds/particles. Next: spawn cow, equip armor/elytra, launch rocket, save/reload and F8 handoff. These checks must happen in actual gameplay; compilation does not establish success.

Canvas orientation: the D3D compositor output is top-origin; Unity RawImage uses bottom-origin texture UVs. RawImage uvRect (0,1,1,-1) flips the final presentation once. World depth comparison stays in D3D top-origin space. Second live launch confirms transport and rendering; screenshot confirmed final canvas was inverted.

Input ownership: live guest CTRL_OVERRIDE_CAMERA leases mouse control. Host CursorManager.SetLocked/SetFree are suppressed while leased; host cursor lock/visibility restore on handoff, watchdog, exception or disposal. Native localHasMenuOpen and Steam overlay gate drive; localApplicationHasNoFocus must not, because the nearly transparent Minecraft input window is foreground. Menu selection and return/F8 need live validation.

Color: actual guest CPU readback is GL_BGRA/UNSIGNED_INT_8_8_8_8_REV; native color input SRVs use B8G8R8A8_UNORM, output remains R8G8B8A8_UNORM. Native test uses original BGRA bytes and validates distinct red/green/blue output.
Performance: half transferred dimensions,45-60fps budget, vsync off, private Minecraft view6/simulation4. Frame header0x38 holds UTC capture milliseconds, native exported frame age measures capture-to-render callback only.
Wake: PlayerSleeper.Update prefix calls RecordAction for the local host player only while guest input lease is active. Native forced sleep behavior and other players remain controlled by Big Walk.

Native objects: PlayerCaster.LocalUpdate uses synchronized player camera and native target reach. R passes safe CastableTarget outcome checks to PlayerDecisions.UseCastableTarget, or safe props to PlayerActions.ActionPickUpProp. G uses ActionDropPropOrPlayer. V uses held switches and up-switch actions. Held world switches release through ActionReleaseWorldSwitch on up/handoff/reach loss. No native puzzle state is directly changed. Native poses remain F8 movement. Camera/root orientation follows guest aim so native carrying and targeting use the same direction.
Protocol headerC0 interaction buttons (R bit0,V bit1),C4 drop request,C8 use request. Existing R request70/ack74/result78 preserved. Prompt80..BF remains64 bytes and non-overlapping.
